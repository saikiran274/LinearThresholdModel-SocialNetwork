# -*- coding: utf-8 -*-


fileName="C:/Users/Chandu/Desktop/BITS/GAL/InfulenceAlgo/data/lastfm_asia_edges.csv"

f = open (fileName)
lines = f.readlines()

for line in lines :
    if line[0] == "#" :
        continue
    line=line.strip()
    print(line.split(','))
    node1, node2 = map(int, line.split(','))
    
    break